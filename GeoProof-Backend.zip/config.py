import os
from typing import List
from pydantic import BaseSettings


class Settings(BaseSettings):
    # ==================== APP SETTINGS ====================
    APP_NAME: str = "GeoProof Backend"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = os.getenv("DEBUG", "True").lower() == "true"
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", 8000))
    
    # ==================== DATABASE ====================
    # PostgreSQL Database URL
    # Format: postgresql://username:password@host:port/database_name
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql://geoproof:geoproof123@localhost:5432/geoproof_db"
    )
    
    DB_POOL_SIZE: int = int(os.getenv("DB_POOL_SIZE", 5))
    DB_MAX_OVERFLOW: int = int(os.getenv("DB_MAX_OVERFLOW", 10))
    
    # ==================== SECURITY ====================
    SECRET_KEY: str = os.getenv(
        "SECRET_KEY",
        "your-super-secret-key-change-this-in-production-12345678"
    )
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    
    # ==================== FILE UPLOAD ====================
    UPLOAD_DIR: str = os.getenv("UPLOAD_DIR", "./uploads/original")
    WATERMARKED_DIR: str = os.getenv("WATERMARKED_DIR", "./uploads/watermarked")
    QR_CODE_DIR: str = os.getenv("QR_CODE_DIR", "./uploads/qr_codes")
    PDF_DIR: str = os.getenv("PDF_DIR", "./uploads/reports")
    
    MAX_UPLOAD_SIZE: int = 50 * 1024 * 1024  # 50 MB
    ALLOWED_IMAGE_FORMATS: List[str] = ["image/jpeg", "image/png", "image/webp"]
    
    # ==================== CORS ====================
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost",
        "http://localhost:3000",
        "http://localhost:8000",
        "https://your-domain.com",  # Update this
    ]
    
    # ==================== AWS S3 (Optional) ====================
    USE_S3: bool = os.getenv("USE_S3", "False").lower() == "true"
    AWS_ACCESS_KEY_ID: str = os.getenv("AWS_ACCESS_KEY_ID", "")
    AWS_SECRET_ACCESS_KEY: str = os.getenv("AWS_SECRET_ACCESS_KEY", "")
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    AWS_S3_BUCKET: str = os.getenv("AWS_S3_BUCKET", "geoproof-uploads")
    
    # ==================== EMAIL (Optional) ====================
    SMTP_HOST: str = os.getenv("SMTP_HOST", "")
    SMTP_PORT: int = int(os.getenv("SMTP_PORT", 587))
    SMTP_USER: str = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD: str = os.getenv("SMTP_PASSWORD", "")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
