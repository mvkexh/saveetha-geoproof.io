# 🔐 GeoProof Backend - Production-Ready API

**AI-Powered Geo-Tagged Image Verification System**

A complete backend solution for the GeoProof mobile application, providing secure image verification with GPS coordinates, digital signatures, and anti-tampering protection.

---

## 📋 Table of Contents

- [Features](#features)
- [Architecture](#architecture)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [API Documentation](#api-documentation)
- [Database Schema](#database-schema)
- [Deployment](#deployment)
- [Configuration](#configuration)
- [Troubleshooting](#troubleshooting)

---

## ✨ Features

### Core Functionality
- ✅ **Image Upload & Verification** - Capture with GPS coordinates and timestamp
- ✅ **Digital Watermarking** - Embed verification data into image pixels
- ✅ **QR Code Generation** - Create scannable verification codes
- ✅ **Anti-Tampering Protection** - Detect image modifications
- ✅ **GPS Encryption** - Secure location data
- ✅ **PDF Report Generation** - Professional verification certificates

### Technical Features
- 🔐 **JWT Authentication** - Secure token-based auth
- 📊 **Real-time Analytics** - Verification dashboard
- 🗄️ **PostgreSQL Database** - Enterprise-grade data storage
- 🚀 **Docker Support** - Easy containerized deployment
- 📦 **Redis Caching** - Performance optimization
- 🔄 **Rate Limiting** - Protect against abuse
- 📝 **Comprehensive Logging** - Audit trail for security

---

## 🏗️ Architecture

```
┌─────────────┐
│ Mobile App  │
│  (Android)  │
└──────┬──────┘
       │ HTTPS
       ▼
┌─────────────────────┐
│  Nginx Reverse Proxy│
│  (SSL/TLS, CORS)    │
└──────┬──────────────┘
       │
       ▼
┌─────────────────────────┐
│   FastAPI Backend       │
│  - Auth                 │
│  - Image Processing     │
│  - Verification         │
│  - Reporting            │
└──────┬──────────────────┘
       │
   ┌───┴───┐
   ▼       ▼
┌────┐  ┌─────────┐
│ DB │  │  Redis  │
└────┘  └─────────┘
```

---

## 🚀 Quick Start

### Using Docker (Recommended)
```bash
# 1. Clone repository
git clone <url>
cd geoproof-backend

# 2. Setup environment
cp .env.example .env

# 3. Start services
docker-compose up -d

# 4. Initialize database
docker-compose exec backend python init_db.py

# 5. Access API
# Frontend: http://localhost
# Docs: http://localhost/docs
```

### Local Development
```bash
# 1. Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Setup database (PostgreSQL must be running)
cp .env.example .env
python init_db.py

# 4. Run server
python main.py
# API will be available at http://localhost:8000/docs
```

---

## 📦 Installation

### Requirements
- Python 3.11+ (for local) or Docker 20.10+
- PostgreSQL 12+ (for local)
- 4GB RAM minimum
- 500MB disk space (grows with images)

### File Structure
```
geoproof-backend/
├── main.py                 # FastAPI application
├── models.py              # Database models
├── schemas.py             # Request/response schemas
├── database.py            # Database configuration
├── config.py              # Settings
├── security.py            # Authentication & JWT
├── image_handler.py       # Image processing & watermarking
├── report_generator.py    # PDF report generation
├── init_db.py            # Database initialization
├── Dockerfile            # Docker configuration
├── docker-compose.yml    # Docker Compose stack
├── nginx.conf           # Nginx configuration
├── requirements.txt     # Python dependencies
├── .env.example        # Environment template
├── SETUP_GUIDE.md      # Detailed setup guide
├── QUICKSTART.md       # Quick reference
└── README.md          # This file
```

---

## 📚 API Documentation

### Authentication Endpoints

#### Register User
```http
POST /auth/register
Content-Type: application/x-www-form-urlencoded

email=user@example.com&password=secure_password
```

**Response:**
```json
{
  "message": "User registered successfully",
  "user_id": "uuid-here",
  "email": "user@example.com",
  "access_token": "jwt-token-here",
  "token_type": "bearer"
}
```

#### Login
```http
POST /auth/login
Content-Type: application/x-www-form-urlencoded

email=user@example.com&password=secure_password
```

### Image Verification Endpoints

#### Upload Image
```http
POST /upload
Content-Type: multipart/form-data

file: <image_file>
latitude: 11.0168
longitude: 76.9558
address: Coimbatore, Tamil Nadu, India
location_name: Mechanical Block (optional)
```

**Response:**
```json
{
  "status": "success",
  "verification_id": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2026-06-11T08:40:00Z",
  "location": {
    "latitude": 11.0168,
    "longitude": 76.9558,
    "address": "Coimbatore, Tamil Nadu, India"
  },
  "watermarked_image_url": "/watermarked/watermarked_550e8400.jpg",
  "original_image_url": "/uploads/550e8400.jpg"
}
```

#### Verify Image
```http
GET /verify/550e8400-e29b-41d4-a716-446655440000
```

**Response:**
```json
{
  "verification_id": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2026-06-11T08:40:00Z",
  "location": {
    "latitude": 11.0168,
    "longitude": 76.9558,
    "address": "Coimbatore, Tamil Nadu, India"
  },
  "security_status": {
    "anti_tamper_protection": "Enabled",
    "gps_encryption": "Active",
    "qr_digital_signature": "Secure",
    "anti_tamper_score": 95.0
  },
  "verification_status": "AUTHENTIC"
}
```

#### Get Verification History
```http
GET /history?limit=20&offset=0
```

**Response:**
```json
{
  "status": "success",
  "total": 42,
  "count": 20,
  "history": [
    {
      "verification_id": "550e8400-...",
      "location_name": "Mechanical Block",
      "address": "Coimbatore, India",
      "timestamp": "2026-06-11T08:40:00Z",
      "image_url": "/uploads/550e8400.jpg"
    }
  ]
}
```

### Reporting & Analytics

#### Generate PDF Report
```http
POST /generate-report/550e8400-e29b-41d4-a716-446655440000
```

Returns: PDF file (application/pdf)

#### Get Statistics
```http
GET /stats
```

**Response:**
```json
{
  "total_verifications": 1250,
  "verified_today": 42,
  "active_cloud_sync": true,
  "timestamp": "2026-06-11T08:40:00Z"
}
```

#### Get Recent Locations
```http
GET /locations/recent?limit=10
```

---

## 🗄️ Database Schema

### Users Table
Stores user account information
```sql
id (UUID, PK)
email (VARCHAR, UNIQUE)
hashed_password (VARCHAR)
organization (VARCHAR)
is_active (BOOLEAN)
created_at (TIMESTAMP)
updated_at (TIMESTAMP)
```

### Verifications Table
Stores all image verification records
```sql
id (INTEGER, PK)
verification_id (VARCHAR, UNIQUE)
user_id (VARCHAR)
original_image_path (VARCHAR)
watermarked_image_path (VARCHAR)
qr_code_path (VARCHAR)
latitude (FLOAT)
longitude (FLOAT)
address (TEXT)
location_name (VARCHAR)
file_hash (VARCHAR)
is_verified (BOOLEAN)
anti_tamper_score (FLOAT)
timestamp (TIMESTAMP)
created_at (TIMESTAMP)
updated_at (TIMESTAMP)
```

### Verification Logs Table
Tracks verification actions (verification, flagging, reporting)
```sql
id (INTEGER, PK)
verification_id (VARCHAR)
action (VARCHAR)
performed_by (VARCHAR)
notes (TEXT)
timestamp (TIMESTAMP)
```

### Audit Logs Table
Security audit trail
```sql
id (INTEGER, PK)
action (VARCHAR)
user_id (VARCHAR)
target_id (VARCHAR)
details (TEXT)
ip_address (VARCHAR)
timestamp (TIMESTAMP)
```

---

## 🚀 Deployment

### Production Checklist
- [ ] Change SECRET_KEY in .env
- [ ] Set DEBUG=False
- [ ] Configure HTTPS/SSL certificates
- [ ] Set strong database password
- [ ] Configure ALLOWED_ORIGINS for CORS
- [ ] Setup database backups
- [ ] Configure monitoring
- [ ] Set up log aggregation
- [ ] Enable rate limiting
- [ ] Configure error alerts

### Deploy to Linux Server
```bash
# SSH to server
ssh user@server.com

# Clone repository
git clone <url>
cd geoproof-backend

# Setup environment
cp .env.example .env
nano .env  # Edit configuration

# Start with Docker
docker-compose up -d

# Check status
docker-compose ps
docker-compose logs -f
```

### Production Environment (.env)
```bash
DEBUG=False
SECRET_KEY=your-very-long-random-string-min-32-chars
DATABASE_URL=postgresql://user:password@host:5432/geoproof_db
ALLOWED_ORIGINS=https://app.geoproof.com,https://api.geoproof.com
```

---

## ⚙️ Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DEBUG` | True | Enable debug mode |
| `HOST` | 0.0.0.0 | Server host |
| `PORT` | 8000 | Server port |
| `DATABASE_URL` | postgresql://... | Database connection |
| `SECRET_KEY` | (required) | JWT secret key |
| `UPLOAD_DIR` | ./uploads/original | Upload directory |
| `MAX_UPLOAD_SIZE` | 52428800 | Max file size (bytes) |
| `ALLOWED_ORIGINS` | localhost | CORS origins |

See `.env.example` for all options.

---

## 🔧 Troubleshooting

### Issue: Database Connection Failed
```bash
# Check if PostgreSQL is running
docker-compose logs postgres

# Verify connection string
echo $DATABASE_URL

# Reset database
docker-compose down -v
docker-compose up -d
docker-compose exec backend python init_db.py
```

### Issue: Upload Fails
- Verify file is valid image (JPEG/PNG)
- Check file size (max 50MB)
- Check disk space: `df -h`
- Check permissions: `chmod 755 uploads/`

### Issue: Slow API Response
- Check database connection: `docker-compose logs postgres`
- Monitor resources: `docker stats`
- Check network latency: `ping localhost`

### Issue: Port Already in Use
```bash
# Find process using port 8000
lsof -i :8000

# Kill process
kill -9 <PID>

# Or change port in docker-compose.yml
```

---

## 📊 Monitoring & Logs

### View Logs
```bash
# All services
docker-compose logs

# Specific service
docker-compose logs backend
docker-compose logs postgres

# Real-time
docker-compose logs -f backend

# Last N lines
docker-compose logs --tail=100 backend
```

### Health Check
```bash
# API health
curl http://localhost:8000/health

# Database
docker-compose exec postgres psql -U geoproof -d geoproof_db -c "SELECT 1;"

# Redis
docker-compose exec redis redis-cli ping
```

---

## 📝 Contributing

1. Follow PEP 8 style guide
2. Add docstrings to functions
3. Test changes locally
4. Create pull request with description

---

## 📄 License

Proprietary - Saveetha Engineering

---

## 🤝 Support

**Documentation**: See `SETUP_GUIDE.md` for detailed instructions

**Quick Reference**: See `QUICKSTART.md`

**Issues**: Check logs with `docker-compose logs backend`

**Contact**: admin@saveetha.ac.in

---

## 🎯 Roadmap

- [ ] AWS S3 integration for image storage
- [ ] Machine learning-based tampering detection
- [ ] Real-time notification system
- [ ] Advanced analytics dashboard
- [ ] Blockchain verification layer
- [ ] Mobile app integration testing
- [ ] Multi-language support

---

## Version History

### v1.0.0 (2026-06-11)
- Initial release
- Image upload and verification
- Digital watermarking
- PDF report generation
- User authentication
- Full API documentation

---

**Made with ❤️ for Saveetha University**
