from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime


# ==================== AUTH SCHEMAS ====================
class UserRegister(BaseModel):
    email: str
    password: str
    organization: Optional[str] = None


class UserLogin(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    user_id: str
    email: str


# ==================== VERIFICATION SCHEMAS ====================
class LocationData(BaseModel):
    latitude: float
    longitude: float
    address: str
    location_name: Optional[str] = None


class UploadRequest(BaseModel):
    latitude: float
    longitude: float
    address: str
    location_name: Optional[str] = "Unknown Location"


class VerificationResponse(BaseModel):
    status: str
    verification_id: str
    message: str
    timestamp: str
    location: Dict[str, Any]
    watermarked_image_url: str
    original_image_url: str


class SecurityStatus(BaseModel):
    anti_tamper_protection: str
    gps_encryption: str
    qr_digital_signature: str
    anti_tamper_score: float


class VerificationDetail(BaseModel):
    verification_id: str
    timestamp: str
    location: Dict[str, Any]
    security_status: Dict[str, Any]
    image_url: str
    watermarked_image_url: str
    is_verified: bool
    verification_status: str


class HistoryItem(BaseModel):
    verification_id: str
    location_name: str
    address: str
    timestamp: str
    image_url: str
    thumbnail_url: str


class HistoryResponse(BaseModel):
    status: str
    total: int
    limit: int
    offset: int
    count: int
    history: list


# ==================== STATISTICS SCHEMAS ====================
class StatsResponse(BaseModel):
    total_verifications: int
    verified_today: int
    active_cloud_sync: bool
    timestamp: str


class LocationItem(BaseModel):
    name: str
    address: str
    latitude: float
    longitude: float
    timestamp: str
    verification_id: str


class LocationsResponse(BaseModel):
    locations: list[LocationItem]


# ==================== ERROR RESPONSE ====================
class ErrorResponse(BaseModel):
    detail: str
    status_code: int
    timestamp: str
