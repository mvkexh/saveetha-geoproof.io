# GeoProof Backend - Quick Start

## Start with Docker (Easiest)

```bash
# 1. Clone/Download files
cd geoproof-backend

# 2. Setup environment
cp .env.example .env

# 3. Start all services
docker-compose up -d

# 4. Wait for services to be healthy
docker-compose ps

# 5. Initialize database
docker-compose exec backend python database.py

# 6. Access API
# Frontend: http://localhost
# Docs: http://localhost/docs
# Health: http://localhost/health
```

## Start Locally (Development)

```bash
# 1. Prerequisites: Python 3.11+, PostgreSQL running

# 2. Install
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3. Database
createdb geoproof_db

# 4. Environment
cp .env.example .env
# Edit .env - change DATABASE_URL if needed

# 5. Initialize
python database.py

# 6. Run
python main.py
# or
uvicorn main:app --reload

# 7. Access
# API: http://localhost:8000
# Docs: http://localhost:8000/docs
```

## Test the API

### 1. Register User
```bash
curl -X POST http://localhost:8000/auth/register \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "email=test@example.com&password=password123"
```

### 2. Upload Image
```bash
curl -X POST http://localhost:8000/upload \
  -F "file=@your_image.jpg" \
  -F "latitude=11.0168" \
  -F "longitude=76.9558" \
  -F "address=Coimbatore, India" \
  -F "location_name=Test Location"
```

### 3. Verify Image
```bash
curl http://localhost:8000/verify/YOUR_VERIFICATION_ID
```

### 4. View History
```bash
curl http://localhost:8000/history
```

## Troubleshooting

### Port Already in Use
```bash
# Change port in docker-compose.yml (line ~50)
# Or kill process:
lsof -i :8000
kill -9 <PID>
```

### Database Connection Error
```bash
# Check PostgreSQL
docker-compose logs postgres

# Reset database
docker-compose down -v
docker-compose up -d postgres
docker-compose up -d
docker-compose exec backend python database.py
```

### File Upload Fails
- Check file size (max 50MB)
- Use JPEG or PNG
- Check disk space

## Production Deployment

See `SETUP_GUIDE.md` for complete production setup with SSL, monitoring, and backups.

## Need Help?

- Check SETUP_GUIDE.md for detailed documentation
- View API docs at `/docs` endpoint
- Check logs: `docker-compose logs backend`
