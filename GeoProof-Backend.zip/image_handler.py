from PIL import Image, ImageDraw, ImageFont
import qrcode
import json
from datetime import datetime
import os
from config import settings
from typing import Dict, Any


def add_watermark(
    image_path: str,
    verification_id: str,
    latitude: float,
    longitude: float,
    address: str,
    timestamp: datetime
) -> str:
    """
    Add watermark with verification details to image
    Embeds QR code and metadata to prevent tampering
    """
    try:
        # Open original image
        img = Image.open(image_path)
        img_copy = img.copy()
        
        # Create watermark overlay with QR code
        watermark = Image.new("RGBA", img_copy.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(watermark)
        
        # Load font (using default if unavailable)
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
            small_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 10)
        except:
            font = ImageFont.load_default()
            small_font = font
        
        # Generate QR code
        qr_data = {
            "verification_id": verification_id,
            "latitude": latitude,
            "longitude": longitude,
            "timestamp": timestamp.isoformat(),
            "address": address
        }
        
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=3,
            border=2,
        )
        qr.add_data(json.dumps(qr_data))
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")
        
        # Resize QR code to fit in bottom left corner
        qr_size = 80
        qr_img = qr_img.resize((qr_size, qr_size), Image.Resampling.LANCZOS)
        
        # Paste QR code to watermark
        qr_position = (10, img_copy.height - qr_size - 10)
        watermark.paste(qr_img, qr_position, qr_img)
        
        # Add text watermark
        text_x = qr_size + 30
        text_y = img_copy.height - 120
        
        watermark_text = [
            f"Verification ID: {verification_id[:16]}...",
            f"Location: {address[:40]}",
            f"Lat: {latitude:.6f}, Lng: {longitude:.6f}",
            f"Time: {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            "GeoProof Verified - Anti-Tamper Protected"
        ]
        
        # Draw semi-transparent background for text
        text_bg_height = len(watermark_text) * 18 + 10
        draw.rectangle(
            [text_x - 5, text_y - 5, img_copy.width - 10, text_y + text_bg_height],
            fill=(0, 0, 0, 180),
            outline=(0, 200, 100, 255),
            width=2
        )
        
        # Draw text
        for i, line in enumerate(watermark_text):
            draw.text(
                (text_x, text_y + i * 18),
                line,
                font=small_font,
                fill=(0, 255, 100, 255)
            )
        
        # Composite watermark onto image
        if img_copy.mode != "RGBA":
            img_copy = img_copy.convert("RGBA")
        
        img_copy = Image.alpha_composite(img_copy, watermark)
        
        # Save watermarked image
        output_filename = f"watermarked_{verification_id}.jpg"
        output_path = os.path.join(settings.WATERMARKED_DIR, output_filename)
        
        # Convert back to RGB for JPEG
        if img_copy.mode == "RGBA":
            img_copy = img_copy.convert("RGB")
        
        img_copy.save(output_path, "JPEG", quality=95)
        
        return output_path
    
    except Exception as e:
        raise Exception(f"Watermarking failed: {str(e)}")


def generate_qr_code(
    verification_id: str,
    data: Dict[str, Any]
) -> str:
    """
    Generate standalone QR code for verification
    Contains all verification data in encoded format
    """
    try:
        qr = qrcode.QRCode(
            version=2,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        
        qr.add_data(json.dumps(data))
        qr.make(fit=True)
        
        qr_img = qr.make_image(fill_color="black", back_color="white")
        
        output_filename = f"qr_{verification_id}.png"
        output_path = os.path.join(settings.QR_CODE_DIR, output_filename)
        
        qr_img.save(output_path)
        
        return output_path
    
    except Exception as e:
        raise Exception(f"QR code generation failed: {str(e)}")


def extract_metadata(image_path: str) -> Dict[str, Any]:
    """
    Extract metadata from image for verification
    Returns EXIF data and image properties
    """
    try:
        img = Image.open(image_path)
        metadata = {
            "size": img.size,
            "format": img.format,
            "mode": img.mode,
            "width": img.width,
            "height": img.height
        }
        
        # Try to extract EXIF data
        try:
            from PIL.Image import Exif
            exif = img.getexif()
            if exif:
                metadata["exif"] = {str(k): str(v) for k, v in exif.items()}
        except:
            pass
        
        return metadata
    
    except Exception as e:
        raise Exception(f"Metadata extraction failed: {str(e)}")


def verify_image_integrity(image_path: str) -> bool:
    """
    Verify image integrity and check for tampering signs
    Returns True if image appears legitimate
    """
    try:
        img = Image.open(image_path)
        # Attempt to verify image integrity
        img.verify()
        return True
    except Exception:
        return False


def compress_image(
    image_path: str,
    quality: int = 85,
    max_width: int = 1920
) -> str:
    """
    Compress image for storage optimization
    """
    try:
        img = Image.open(image_path)
        
        # Resize if width exceeds max_width
        if img.width > max_width:
            ratio = max_width / img.width
            new_height = int(img.height * ratio)
            img = img.resize((max_width, new_height), Image.Resampling.LANCZOS)
        
        # Save compressed
        img.save(image_path, "JPEG", quality=quality, optimize=True)
        
        return image_path
    
    except Exception as e:
        raise Exception(f"Image compression failed: {str(e)}")
