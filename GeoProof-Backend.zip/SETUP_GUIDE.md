# GeoProof Backend - Setup & Deployment Guide

## Overview
This is a production-ready FastAPI backend for the GeoProof application - an AI-powered geo-tagged image verification system.

## Tech Stack
- **Framework**: FastAPI 0.104.1
- **Database**: PostgreSQL 15
- **Image Processing**: Pillow, QRCode
- **Authentication**: JWT (python-jose)
- **Server**: Gunicorn + Uvicorn
- **Reverse Proxy**: Nginx
- **Containerization**: Docker & Docker Compose

---

## Quick Start (Development)

### Prerequisites
- Python 3.11+
- PostgreSQL 12+
- Git

### 1. Clone the Repository
```bash
git clone <your-repo-url>
cd geoproof-backend
```

### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Setup Environment
```bash
cp .env.example .env
# Edit .env with your configuration
```

### 5. Create Database
```bash
# Make sure PostgreSQL is running
psql -U postgres
CREATE DATABASE geoproof_db;
CREATE USER geoproof WITH PASSWORD 'geoproof123';
GRANT ALL PRIVILEGES ON DATABASE geoproof_db TO geoproof;
\q
```

### 6. Initialize Database Tables
```bash
python database.py
```

### 7. Run Development Server
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at: `http://localhost:8000`
- API Docs: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

---

## Docker Setup (Recommended for Production)

### Prerequisites
- Docker 20.10+
- Docker Compose 1.29+

### 1. Clone Repository
```bash
git clone <your-repo-url>
cd geoproof-backend
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your settings
```

### 3. Start Services
```bash
docker-compose up -d
```

This will start:
- PostgreSQL database
- FastAPI backend
- Redis cache
- Nginx reverse proxy

### 4. Initialize Database
```bash
docker-compose exec backend python database.py
```

### 5. Check Status
```bash
docker-compose ps
docker-compose logs -f backend
```

### 6. Access Application
- API: `http://localhost`
- API Docs: `http://localhost/docs`
- Health Check: `http://localhost/health`

---

## API Endpoints

### Authentication
```
POST   /auth/register          - Register new user
POST   /auth/login              - Login and get token
```

### Image Verification
```
POST   /upload                  - Upload image with GPS data
GET    /verify/{verification_id} - Get verification details
GET    /history                 - Get user's verification history
```

### Reporting
```
POST   /generate-report/{id}    - Generate PDF report
```

### Statistics
```
GET    /stats                   - Get verification stats
GET    /locations/recent        - Get recent locations
```

### Health & Info
```
GET    /health                  - Health check
GET    /docs                    - API documentation
```

---

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    organization VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

### Verifications Table
```sql
CREATE TABLE verifications (
    id INTEGER PRIMARY KEY,
    verification_id VARCHAR(255) UNIQUE NOT NULL,
    user_id VARCHAR(255),
    original_image_path VARCHAR(255),
    watermarked_image_path VARCHAR(255),
    qr_code_path VARCHAR(255),
    latitude FLOAT NOT NULL,
    longitude FLOAT NOT NULL,
    address TEXT NOT NULL,
    location_name VARCHAR(255),
    file_hash VARCHAR(255),
    is_verified BOOLEAN,
    anti_tamper_score FLOAT,
    timestamp TIMESTAMP,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

---

## Configuration

### Environment Variables (Critical)

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `SECRET_KEY` | JWT secret key (change in production!) | Yes |
| `DEBUG` | Enable debug mode | No |
| `HOST` | Server host | No |
| `PORT` | Server port | No |
| `UPLOAD_DIR` | Path for uploaded images | No |
| `MAX_UPLOAD_SIZE` | Max file size in bytes | No |

### Example Production .env
```bash
DEBUG=False
HOST=0.0.0.0
PORT=8000

DATABASE_URL=postgresql://geoproof:secure_password@db.example.com:5432/geoproof_prod

SECRET_KEY=your-production-secret-key-min-32-chars-long-random-string
ALGORITHM=HS256

UPLOAD_DIR=/var/geoproof/uploads/original
WATERMARKED_DIR=/var/geoproof/uploads/watermarked
PDF_DIR=/var/geoproof/uploads/reports

ALLOWED_ORIGINS=https://geoproof.example.com,https://api.geoproof.example.com
```

---

## Image Upload Example

### Using cURL
```bash
curl -X POST http://localhost:8000/upload \
  -F "file=@image.jpg" \
  -F "latitude=11.0168" \
  -F "longitude=76.9558" \
  -F "address=Coimbatore, Tamil Nadu, India" \
  -F "location_name=Mechanical Block, Saveetha University"
```

### Using Python
```python
import requests

files = {'file': open('image.jpg', 'rb')}
data = {
    'latitude': 11.0168,
    'longitude': 76.9558,
    'address': 'Coimbatore, Tamil Nadu, India',
    'location_name': 'Mechanical Block'
}

response = requests.post(
    'http://localhost:8000/upload',
    files=files,
    data=data
)

print(response.json())
```

### Response
```json
{
  "status": "success",
  "verification_id": "550e8400-e29b-41d4-a716-446655440000",
  "message": "Image uploaded and verified successfully",
  "timestamp": "2026-06-11T08:40:00.000Z",
  "location": {
    "latitude": 11.0168,
    "longitude": 76.9558,
    "address": "Coimbatore, Tamil Nadu, India"
  },
  "watermarked_image_url": "/watermarked/watermarked_550e8400.jpg",
  "original_image_url": "/uploads/550e8400.jpg"
}
```

---

## Verification Check Example

### Using cURL
```bash
curl -X GET http://localhost:8000/verify/550e8400-e29b-41d4-a716-446655440000
```

### Response
```json
{
  "verification_id": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2026-06-11T08:40:00.000Z",
  "location": {
    "latitude": 11.0168,
    "longitude": 76.9558,
    "address": "Coimbatore, Tamil Nadu, India",
    "location_name": "Mechanical Block"
  },
  "security_status": {
    "anti_tamper_protection": "Enabled",
    "gps_encryption": "Active",
    "qr_digital_signature": "Secure",
    "anti_tamper_score": 95.0
  },
  "image_url": "/uploads/550e8400.jpg",
  "watermarked_image_url": "/watermarked/watermarked_550e8400.jpg",
  "is_verified": true,
  "verification_status": "AUTHENTIC"
}
```

---

## Production Deployment

### 1. Server Requirements
- Ubuntu 20.04 LTS or similar
- 4GB RAM minimum
- 20GB storage
- PostgreSQL 12+
- Docker & Docker Compose

### 2. SSL Certificate Setup
```bash
# Using Let's Encrypt with Certbot
sudo apt-get install certbot python3-certbot-nginx
sudo certbot certonly --nginx -d your-domain.com
```

Update `nginx.conf` with certificate paths:
```nginx
ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
```

### 3. Deploy with Docker
```bash
# Pull latest code
git pull origin main

# Rebuild and restart
docker-compose down
docker-compose up -d --build

# Check logs
docker-compose logs -f
```

### 4. Backup Strategy
```bash
# Backup database
docker-compose exec postgres pg_dump -U geoproof geoproof_db > backup_$(date +%Y%m%d).sql

# Backup uploads
tar -czf uploads_backup_$(date +%Y%m%d).tar.gz uploads/
```

### 5. Monitoring
```bash
# Check service health
curl http://localhost/health

# Monitor logs
docker-compose logs -f --tail=100 backend

# Check database
docker-compose exec postgres psql -U geoproof -d geoproof_db -c "SELECT COUNT(*) FROM verifications;"
```

---

## Performance Optimization

### 1. Database Indexing
```sql
CREATE INDEX idx_verification_id ON verifications(verification_id);
CREATE INDEX idx_timestamp ON verifications(timestamp DESC);
CREATE INDEX idx_user_id ON verifications(user_id);
CREATE INDEX idx_user_email ON users(email);
```

### 2. Caching (Redis)
Already configured in docker-compose. Cache verification lookups:
```python
# In main.py, add caching decorator
from functools import lru_cache

@app.get("/verify/{verification_id}")
@lru_cache(maxsize=1000)
async def verify_image(verification_id: str):
    ...
```

### 3. Image Optimization
- Automatic compression on upload
- WebP conversion for better compression
- Thumbnail generation for lists

---

## Troubleshooting

### Database Connection Error
```bash
# Check PostgreSQL status
docker-compose logs postgres

# Reset database
docker-compose down
docker volume rm geoproof-backend_postgres_data
docker-compose up -d postgres
docker-compose exec backend python database.py
```

### Upload Fails
- Check file size (max 50MB)
- Verify image format (JPEG, PNG, WebP)
- Check disk space: `df -h`

### Slow Uploads
- Increase Nginx timeout in nginx.conf
- Check network bandwidth
- Monitor disk I/O

### API Documentation Not Loading
```bash
# Rebuild and restart
docker-compose restart backend

# Check logs
docker-compose logs backend | grep -i error
```

---

## Security Checklist

- [ ] Change `SECRET_KEY` in production
- [ ] Set `DEBUG=False`
- [ ] Use HTTPS with valid SSL certificate
- [ ] Set strong database password
- [ ] Enable CORS only for trusted domains
- [ ] Implement rate limiting (already in Nginx)
- [ ] Regular database backups
- [ ] Monitor logs for suspicious activity
- [ ] Update dependencies regularly
- [ ] Use environment variables for secrets

---

## Connecting Android App

In your Android app (Retrofit configuration):

```kotlin
val retrofit = Retrofit.Builder()
    .baseUrl("https://your-api-domain.com/")
    .addConverterFactory(GsonConverterFactory.create())
    .build()
```

### Example Upload Call
```kotlin
val file = File(imagePath)
val requestBody = file.asRequestBody("image/jpeg".toMediaType())
val multipart = MultipartBody.Part.createFormData("file", file.name, requestBody)

val response = apiService.uploadImage(
    multipart,
    latitude.toFloat(),
    longitude.toFloat(),
    address,
    locationName
)
```

---

## Support & Documentation

- **API Documentation**: `http://your-domain.com/docs`
- **Database Docs**: See models.py
- **Image Processing**: See image_handler.py
- **Security**: See security.py

---

## License
Proprietary - Saveetha Engineering & SIMATS

---

## Contact
For issues and support, contact: admin@saveetha.ac.in
