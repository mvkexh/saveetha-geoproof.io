from datetime import datetime
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor, black, white
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak
from reportlab.platypus.tableofcontents import TableOfContents
import os
from models import Verification
from config import settings


def generate_pdf_report(verification: Verification, output_dir: str) -> str:
    """
    Generate comprehensive PDF verification report
    """
    filename = f"GeoProof-Report-{verification.verification_id}.pdf"
    filepath = os.path.join(output_dir, filename)
    
    # Create PDF
    doc = SimpleDocTemplate(
        filepath,
        pagesize=A4,
        rightMargin=0.5*inch,
        leftMargin=0.5*inch,
        topMargin=0.5*inch,
        bottomMargin=0.5*inch
    )
    
    # Styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=HexColor('#0052CC'),
        spaceAfter=30,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=HexColor('#0052CC'),
        spaceAfter=12,
        fontName='Helvetica-Bold'
    )
    
    normal_style = ParagraphStyle(
        'CustomNormal',
        parent=styles['Normal'],
        fontSize=10,
        spaceAfter=8,
        fontName='Helvetica'
    )
    
    # Content
    story = []
    
    # Header
    story.append(Spacer(1, 0.3*inch))
    story.append(Paragraph("GeoProof Verification Report", title_style))
    story.append(Spacer(1, 0.2*inch))
    
    # Verification ID
    story.append(Paragraph(f"<b>Verification ID:</b> {verification.verification_id}", normal_style))
    story.append(Spacer(1, 0.1*inch))
    
    # Verification Status
    status_color = '#00CC44' if verification.is_verified else '#CC0000'
    status_text = 'AUTHENTIC' if verification.is_verified else 'FLAGGED'
    story.append(
        Paragraph(
            f"<b>Verification Status:</b> <font color='{status_color}'><b>{status_text}</b></font>",
            normal_style
        )
    )
    story.append(Spacer(1, 0.2*inch))
    
    # Location Section
    story.append(Paragraph("Location Information", heading_style))
    location_data = [
        ['Property', 'Value'],
        ['Location Name', verification.location_name or 'N/A'],
        ['Address', verification.address],
        ['Latitude', f"{verification.latitude:.8f}"],
        ['Longitude', f"{verification.longitude:.8f}"],
        ['Timestamp', verification.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')],
    ]
    
    location_table = Table(location_data, colWidths=[2*inch, 3.5*inch])
    location_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), HexColor('#0052CC')),
        ('TEXTCOLOR', (0, 0), (-1, 0), white),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 11),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), HexColor('#F0F0F0')),
        ('GRID', (0, 0), (-1, -1), 1, black),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, HexColor('#F8F8F8')])
    ]))
    story.append(location_table)
    story.append(Spacer(1, 0.3*inch))
    
    # Security Status Section
    story.append(Paragraph("Security Status", heading_style))
    security_data = [
        ['Security Feature', 'Status'],
        ['Anti-Tamper Protection', 'Enabled'],
        ['GPS Encryption', 'Active'],
        ['QR Digital Signature', 'Secure'],
        ['Anti-Tamper Score', f"{verification.anti_tamper_score:.1f}/100"],
    ]
    
    security_table = Table(security_data, colWidths=[2.5*inch, 3*inch])
    security_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), HexColor('#00AA44')),
        ('TEXTCOLOR', (0, 0), (-1, 0), white),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 11),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), HexColor('#F0F0F0')),
        ('GRID', (0, 0), (-1, -1), 1, black),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, HexColor('#F8F8F8')])
    ]))
    story.append(security_table)
    story.append(Spacer(1, 0.3*inch))
    
    # File Information Section
    story.append(Paragraph("File Information", heading_style))
    file_data = [
        ['Property', 'Value'],
        ['File Hash (SHA-256)', verification.file_hash[:32] + '...'],
        ['Image Verification', 'Passed' if verification.is_verified else 'Failed'],
        ['Report Generated', datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')],
    ]
    
    file_table = Table(file_data, colWidths=[2*inch, 3.5*inch])
    file_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), HexColor('#0052CC')),
        ('TEXTCOLOR', (0, 0), (-1, 0), white),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 11),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), HexColor('#F0F0F0')),
        ('GRID', (0, 0), (-1, -1), 1, black),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, HexColor('#F8F8F8')])
    ]))
    story.append(file_table)
    story.append(Spacer(1, 0.4*inch))
    
    # Footer
    footer_text = "This report confirms that the image has been verified using GeoProof technology. The watermarked image contains embedded security metadata that cannot be removed without detection."
    story.append(Paragraph(footer_text, ParagraphStyle(
        'Footer',
        parent=styles['Normal'],
        fontSize=9,
        textColor=HexColor('#666666'),
        alignment=TA_CENTER
    )))
    
    # Build PDF
    doc.build(story)
    
    return filepath
