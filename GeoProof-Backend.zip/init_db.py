#!/usr/bin/env python
"""
Database initialization and migration script for GeoProof
Run this after first deployment to create all tables
"""

import sys
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from models import Base, User, Verification, VerificationLog, AuditLog
from config import settings
from datetime import datetime

def init_database():
    """Initialize database with all tables"""
    try:
        print("🔧 Initializing GeoProof Database...")
        print(f"📍 Database URL: {settings.DATABASE_URL[:50]}...")
        
        # Create engine
        engine = create_engine(settings.DATABASE_URL)
        
        # Test connection
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            print("✅ Database connection successful!")
        
        # Create all tables
        Base.metadata.create_all(bind=engine)
        print("✅ All tables created successfully!")
        
        # Create indexes
        with engine.connect() as conn:
            conn.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_verification_id 
                ON verifications(verification_id)
            """))
            conn.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_timestamp 
                ON verifications(timestamp DESC)
            """))
            conn.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_user_id 
                ON verifications(user_id)
            """))
            conn.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_user_email 
                ON users(email)
            """))
            conn.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_verification_timestamp 
                ON verification_logs(timestamp)
            """))
            conn.commit()
            print("✅ Database indexes created!")
        
        # Summary
        print("\n" + "="*50)
        print("DATABASE INITIALIZATION COMPLETE")
        print("="*50)
        print(f"✅ Timestamp: {datetime.utcnow().isoformat()}")
        print("✅ Tables created:")
        print("   - users")
        print("   - verifications")
        print("   - verification_logs")
        print("   - audit_logs")
        print("\n🚀 You can now start the API server!")
        print("="*50)
        
        return True
    
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        print("\nTroubleshooting:")
        print("1. Ensure PostgreSQL is running")
        print("2. Check DATABASE_URL in .env")
        print("3. Verify database credentials")
        print("4. Check network connectivity")
        return False


def add_sample_data():
    """Add sample data for testing (optional)"""
    try:
        print("\n📝 Adding sample data...")
        
        from database import SessionLocal
        
        db = SessionLocal()
        
        # Check if sample data already exists
        existing = db.query(User).filter(User.email == "demo@geoproof.com").first()
        if existing:
            print("⚠️  Sample data already exists, skipping...")
            db.close()
            return
        
        # Add demo user
        demo_user = User(
            email="demo@geoproof.com",
            hashed_password="$2b$12$e3XcPGfzUe/F9r8Bqx6cN.Z0K7z8XkLmY9pQwQrStU5dN6mHx5vQy",  # password: demo123
            organization="Saveetha University",
            is_active=True
        )
        db.add(demo_user)
        db.commit()
        
        print("✅ Demo user created:")
        print("   Email: demo@geoproof.com")
        print("   Password: demo123")
        
        db.close()
    
    except Exception as e:
        print(f"⚠️  Could not add sample data: {str(e)}")


def check_database_health():
    """Check database health and statistics"""
    try:
        print("\n🏥 Checking Database Health...")
        
        from database import SessionLocal
        
        db = SessionLocal()
        
        users_count = db.query(User).count()
        verifications_count = db.query(Verification).count()
        logs_count = db.query(VerificationLog).count()
        
        print(f"👤 Users: {users_count}")
        print(f"📸 Verifications: {verifications_count}")
        print(f"📋 Logs: {logs_count}")
        
        db.close()
    
    except Exception as e:
        print(f"⚠️  Could not check health: {str(e)}")


if __name__ == "__main__":
    print("\n" + "="*50)
    print("GeoProof Database Setup")
    print("="*50 + "\n")
    
    # Initialize database
    if not init_database():
        sys.exit(1)
    
    # Check health
    check_database_health()
    
    # Optionally add sample data
    if "--sample" in sys.argv:
        add_sample_data()
    
    print("\n✨ Setup complete! You're ready to go!")
