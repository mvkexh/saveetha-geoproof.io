from sqlalchemy import Column, String, Float, DateTime, Boolean, Integer, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base
import uuid
from datetime import datetime

Base = declarative_base()


class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    organization = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Verification(Base):
    __tablename__ = "verifications"
    
    id = Column(Integer, primary_key=True, index=True)
    verification_id = Column(String(255), unique=True, nullable=False, index=True)
    user_id = Column(String(255), nullable=True)
    
    # Image Paths
    original_image_path = Column(String(255), nullable=False)
    watermarked_image_path = Column(String(255), nullable=False)
    qr_code_path = Column(String(255), nullable=True)
    
    # Location Data
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    address = Column(Text, nullable=False)
    location_name = Column(String(255), nullable=True)
    
    # Security & Verification
    file_hash = Column(String(255), nullable=False)
    is_verified = Column(Boolean, default=True)
    anti_tamper_score = Column(Float, default=100.0)
    
    # Metadata
    timestamp = Column(DateTime, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Optional metadata
    device_info = Column(Text, nullable=True)
    camera_metadata = Column(Text, nullable=True)


class VerificationLog(Base):
    __tablename__ = "verification_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    verification_id = Column(String(255), nullable=False, index=True)
    action = Column(String(100), nullable=False)  # "verified", "flagged", "reported"
    performed_by = Column(String(255), nullable=True)
    notes = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    action = Column(String(255), nullable=False)
    user_id = Column(String(255), nullable=True)
    target_id = Column(String(255), nullable=True)
    details = Column(Text, nullable=True)
    ip_address = Column(String(45), nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
